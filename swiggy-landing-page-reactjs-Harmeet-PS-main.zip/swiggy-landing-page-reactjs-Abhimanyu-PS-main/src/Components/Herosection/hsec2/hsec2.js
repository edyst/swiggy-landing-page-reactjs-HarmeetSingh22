import React from 'react'
import '../hero.css'


const hsec2 = () => {
    return (
        <div className="hsec2">
            <h1 className="heading-hsec2"><span className="animation-heading"></span></h1>
            <p className="dull-text">Order food from favourite restaurants near you.</p>
        </div>
    )
}
export default hsec2