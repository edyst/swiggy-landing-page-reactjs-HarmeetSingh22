import { library } from '@fortawesome/fontawesome-svg-core'
import {faCrosshairs } from '@fortawesome/free-solid-svg-icons'

library.add(faCrosshairs)